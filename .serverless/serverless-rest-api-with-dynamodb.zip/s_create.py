import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='juanfranciscomulero',
    application_name='todo-list-serverless',
    app_uid='gGk7VMHBDRdkKgdpKZ',
    org_uid='91555264-21a2-4bbc-bd1e-11d4ccab1127',
    deployment_uid='406602f1-6ba0-4513-a563-6dda13d481cf',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-create', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/create.create')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
